# Paquete workshop — participante N1

## Contenido

- `toolkit-spec-1.yaml` → importa tu toolkit `N1_fraud_mcp`
- `agent-spec-1.yaml` → importa tu agente `N1_fraud_analyst`
- `tools/` → código MCP (lo usa Orchestrate al importar el toolkit)

## Pasos

1. Abre una terminal **en esta carpeta** (donde están los YAML).
2. Crea y activa el entorno virtual:

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate          # Windows: .venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install ibm-watsonx-orchestrate
   pip install -r tools/requirements.txt
   ```

3. Activa la instancia TechZone (usa la API key que te entregó IBM):

   ```bash
   orchestrate env activate workshop --api-key <API_KEY_ORCHESTRATE>
   ```

   Si aún no agregaste el ambiente: `orchestrate env add --name workshop --url <URL_INSTANCIA>`

4. Importa **tu toolkit** (conexión `workshop_confluent` ya creada por IBM):

   ```bash
   orchestrate toolkits import --file toolkit-spec-1.yaml --app-id workshop_confluent
   orchestrate toolkits list
   ```

5. Importa **tu agente**:

   ```bash
   orchestrate agents import --file agent-spec-1.yaml
   orchestrate agents list
   ```

6. Abre watsonx Orchestrate en el navegador y prueba `N1_fraud_analyst`.

## Tu tópico

`TransaccionesEvaluadas-1` — el agente siempre pasa `topic_number="1"` a las tools.
No aparece en la pantalla de Conexiones; lo fija el agente al llamar las tools.

## Prerequisito

`Pipeline_1` en ejecución y publicando Avro en `TransaccionesEvaluadas-1`.
